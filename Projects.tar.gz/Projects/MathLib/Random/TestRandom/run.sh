#!/bin/bash
PROJECT_NAME=test_random
./${PROJECT_NAME} --RandomConstructor1
./${PROJECT_NAME} --RandomConstructor2
./${PROJECT_NAME} --RandomConstructor3
./${PROJECT_NAME} --RandomConstructor4
./${PROJECT_NAME} --TestSetSeed       
./${PROJECT_NAME} --TestGetSeed       
./${PROJECT_NAME} --TestGenerate1     
./${PROJECT_NAME} --TestGenerate2     
./${PROJECT_NAME} --Generate          
